<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'laundry_erp');
define('DB_USER', 'root');
define('DB_PASS', '');
?>
<?php
/* definations */
define('DATABASE_PATH', 'settings/database/');

/* include files */
include DATABASE_PATH.'database.php';


?>